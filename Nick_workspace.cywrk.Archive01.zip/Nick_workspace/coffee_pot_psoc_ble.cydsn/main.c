//Power pin project
//Nick McMillan

#include <project.h>

//Function sends the current state of the LED to the GATT server
void update_led()
{
    CYBLE_GATTS_HANDLE_VALUE_NTF_T tempHandle;
    int currentLED = (!control_led_Read());
    
    if(CyBle_GetState() != CYBLE_STATE_CONNECTED)
        return;
    
    tempHandle.attrHandle = CYBLE_POWCONTROL_SERV_LED_CHAR_HANDLE;
    tempHandle.value.val = (uint8_t *)&currentLED;
    tempHandle.value.len = 1;
    CyBle_GattsWriteAttributeValue(&tempHandle,0,&cyBle_connHandle,0);
}

//event handler of BLE actions
void BleCallBack(uint32_t event, void* eventParam)
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    switch(event)
    {
        case CYBLE_EVT_STACK_ON:
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            //no notifications to stop
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            break;
            
        case CYBLE_EVT_GATT_CONNECT_IND:
            update_led();
            break;
            
        case CYBLE_EVT_GATTS_WRITE_REQ:
            wrReqParam = (CYBLE_GATTS_WRITE_CMD_REQ_PARAM_T *) eventParam;
            //write LED
            if(CYBLE_GATT_ERR_NONE == CyBle_GattsWriteAttributeValue(&wrReqParam->handleValPair, 0, &cyBle_connHandle, CYBLE_GATT_DB_PEER_INITIATED));
            {
                control_led_Write(!wrReqParam->handleValPair.value.val[0]);
                CyBle_GattsWriteRsp(cyBle_connHandle); //write response
            }
            break;
        
        default:
            break;
    }
}

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    CyBle_Start(BleCallBack); //Start BLE with event handler BleCallBack

    for(;;)
    {
        CyBle_ProcessEvents();
    }
}
